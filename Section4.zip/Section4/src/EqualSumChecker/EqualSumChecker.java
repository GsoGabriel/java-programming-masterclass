package EqualSumChecker;

public class EqualSumChecker {
    public static boolean hasEqualSum(int numOne, int numTwo, int numThree){
        return numOne + numTwo == numThree;
    }

}
