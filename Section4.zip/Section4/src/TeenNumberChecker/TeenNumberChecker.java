package TeenNumberChecker;

public class TeenNumberChecker {
    public static boolean hasTeen(int personOne, int personTwo, int personThree){
        if (isTeen(personOne) || isTeen(personTwo) || isTeen(personThree)){
            return true;
        }else {
            return false;
        }
    }

    public static boolean isTeen(int person){
        if (person >= 13 && person <= 19){
            return true;
        }else {
            return false;
        }
    }
}
