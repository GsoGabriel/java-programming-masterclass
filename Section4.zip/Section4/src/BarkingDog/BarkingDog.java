package BarkingDog;

public class BarkingDog {
    public static boolean shouldWakeUp(boolean isBarking, int hourOfDay){
        if ((hourOfDay < 0 || hourOfDay > 23) || !isBarking) {
            return false;
        } else {
            if (hourOfDay < 8 || hourOfDay > 22){
                return true;
            }else {
                return false;
            }
        }
    }
}
