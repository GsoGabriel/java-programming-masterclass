package MegabyteConverter;

public class MegaByteConverterTest {
    public static void main(String[] args) {
        MegabyteConverter.printMegaBytesAndKiloBytes(2500);
        MegabyteConverter.printMegaBytesAndKiloBytes(-1024);
        MegabyteConverter.printMegaBytesAndKiloBytes(5000);
    }
}
